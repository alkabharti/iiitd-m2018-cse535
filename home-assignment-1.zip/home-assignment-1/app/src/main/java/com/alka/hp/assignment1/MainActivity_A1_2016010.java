package com.alka.hp.assignment1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity_A1_2016010 extends AppCompatActivity {
    Button submit,clear;
    EditText editText1,editText2,editText3,editText4,editText5,editText6,editText7;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main__a1_2016010);
        Log.i("hii","Method onCreate");
        Toast.makeText(this,"Created",Toast.LENGTH_SHORT).show();

        editText1=(EditText) findViewById(R.id.editText);
        editText2=(EditText) findViewById(R.id.editText8);
        editText3=(EditText) findViewById(R.id.editText9);
        editText4=(EditText) findViewById(R.id.editText10);
        editText5=(EditText) findViewById(R.id.editText11);
        editText6=(EditText) findViewById(R.id.editText12);
        editText7=(EditText) findViewById(R.id.editText13);
        submit=(Button) findViewById(R.id.button);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String namevalue=editText1.getText().toString();
                String roll=editText2.getText().toString();
                String branch=editText3.getText().toString();
                String one=editText4.getText().toString();
                String two=editText5.getText().toString();
                String three=editText6.getText().toString();
                String four=editText7.getText().toString();
                Intent intent=new Intent(MainActivity_A1_2016010.this,Activity2_A1_2016010.class);
                intent.putExtra("name",namevalue);
                intent.putExtra("roll",roll);
                intent.putExtra("branch",branch);
                intent.putExtra("one",one);
                intent.putExtra("two",two);
                intent.putExtra("three",three);
                intent.putExtra("four",four);
                startActivity(intent);
            }
        });
        clear=(Button) findViewById(R.id.button2);
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText1.setText("");
                editText2.setText("");
                editText3.setText("");
                editText4.setText("");
                editText5.setText("");
                editText6.setText("");
                editText7.setText("");
            }
        });
    }
    @Override
    protected void onStart()
    {
        super.onStart();
        Log.i("hii","Activity Started");
        Toast.makeText(this,"Activity Started",Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onResume()
    {
        super.onResume();
        Log.i("hii","Activity changed from start to Resume");
        Toast.makeText(this,"Activity changed from start to Resume",Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onPause()
    {
        super.onPause();
        Log.i("hii","Activity changed from resume to Pause");
        Toast.makeText(this,"Activity changed from resume to Pause",Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.i("hii", "Activity changed from pause to Stop");
        Toast.makeText(this, "Activity changed from pause to Stop", Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("hii", "Activity changed from Stop to Destroy");
        Toast.makeText(this, "Activity changed from Stop to Destroy", Toast.LENGTH_SHORT).show();
    }


}
