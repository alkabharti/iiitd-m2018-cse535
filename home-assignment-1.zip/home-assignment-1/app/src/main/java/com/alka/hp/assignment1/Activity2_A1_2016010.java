package com.alka.hp.assignment1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Activity2_A1_2016010 extends AppCompatActivity {
    TextView textView1,textView2,textView3,textView4,textView5,textView6,textView7;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity2__a1_2016010);
        textView1=(TextView) findViewById(R.id.textView4);
        textView2=(TextView) findViewById(R.id.textView12);
        textView3=(TextView) findViewById(R.id.textView13);
        textView4=(TextView) findViewById(R.id.textView14);
        textView5=(TextView) findViewById(R.id.textView15);
        textView6=(TextView) findViewById(R.id.textView16);
        textView7=(TextView) findViewById(R.id.textView17);

        textView1.setText(getIntent().getStringExtra("name"));
        textView2.setText(getIntent().getStringExtra("roll"));
        textView3.setText(getIntent().getStringExtra("branch"));
        textView4.setText(getIntent().getStringExtra("one"));
        textView5.setText(getIntent().getStringExtra("two"));
        textView6.setText(getIntent().getStringExtra("three"));
        textView7.setText(getIntent().getStringExtra("four"));
    }
}
