package com.example.hp.homework4;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDatabase extends SQLiteOpenHelper
{
    public SQLiteDatabase db;
    public static final String Database_name="Sensor_data2.db";
    public static final String Table_accelerometer="accelerometer";
    public static final String col_ax="x_value";
    public static final String col_ay="y_value";
    public static final String col_az="z_value";
    public static final String col_atimestamp="time";

    public static final String Table_gyroscope="gyroscope";
    public static final String col_gx="x_value";
    public static final String col_gy="y_value";
    public static final String col_gz="z_value";
    public static final String col_gtimestamp="time";

    public static final String Table_gps="gps";
    public static final String col_lat="lat_value";
    public static final String col_lon="lon_value";
    public static final String col_timestamp="time";

    public static final String Table_orinetation="orientation";
    public static final String col_ox="x_value";
    public static final String col_oy="y_value";
    public static final String col_oz="z_value";
    public static final String col_otimestamp="time";

    public static final String Table_proximity="proximity";
    public static final String col_p="p_value";
    public static final String col_ptimestamp="time";

    public MyDatabase(Context context) {
        super(context,Database_name,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;
        db.execSQL(" CREATE TABLE " + Table_accelerometer + " (x_value TEXT, y_value TEXT, z_value TEXT, time TEXT) ");
        db.execSQL(" CREATE TABLE " + Table_gyroscope + " (x_value TEXT, y_value TEXT, z_value TEXT, time TEXT) ");
        db.execSQL(" CREATE TABLE " + Table_gps + " (lat_value TEXT, lon_value TEXT, time TEXT) ");
        db.execSQL(" CREATE TABLE " + Table_orinetation + " (x_value TEXT, y_value TEXT, z_value TEXT, time TEXT) ");
        db.execSQL(" CREATE TABLE " + Table_proximity + " (p_value TEXT, time TEXT) ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + Table_accelerometer);
        onCreate(db);
    }
}
