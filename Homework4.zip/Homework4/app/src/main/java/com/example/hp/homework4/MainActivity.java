package com.example.hp.homework4;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.PersistableBundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Surface;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import static com.example.hp.homework4.MyDatabase.*;

public class MainActivity extends AppCompatActivity implements SensorEventListener,LocationListener {
    MyDatabase myDatabase;
    private static final String TAG="MainActivity";
    private SensorManager sensorManager;
    Sensor accelerometer,gyroscope,or,prox;
    LocationManager locationManager;
    TextView xvalue,yvalue,zvalue,gxvalue,gyvalue,gzvalue,lat,lon,ox,oy,oz,proximity;
    Button start,stop,check;
    private float aval,al,shake;
    boolean init;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDatabase=new MyDatabase(this);
        xvalue=findViewById(R.id.textView4);
        yvalue=findViewById(R.id.textView5);
        zvalue=findViewById(R.id.textView6);
        gxvalue=findViewById(R.id.textView8);
        gyvalue=findViewById(R.id.textView2);
        gzvalue=findViewById(R.id.textView);
        start=findViewById(R.id.button);
        stop=findViewById(R.id.button3);
        lat=findViewById(R.id.textView11);
        lon=findViewById(R.id.textView12);
        ox=findViewById(R.id.textView14);
        oy=findViewById(R.id.textView15);
        oz=findViewById(R.id.textView16);
        proximity=findViewById(R.id.textView18);
        check=findViewById(R.id.button2);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start.setEnabled(false);
                stop.setEnabled(true);
                sensorManager=(SensorManager) getSystemService(Context.SENSOR_SERVICE);
                accelerometer=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
                if(accelerometer!=null)
                {
                    sensorManager.registerListener(MainActivity.this,accelerometer,SensorManager.SENSOR_DELAY_NORMAL);
                    init =false;
                }
                else
                {
                    Toast.makeText(MainActivity.this,"Accelerometer not suported",Toast.LENGTH_SHORT).show();
                    xvalue.setText("not supported");
                    yvalue.setText("not supported");
                    zvalue.setText("not supported");
                }
                aval=sensorManager.GRAVITY_EARTH;
                al=sensorManager.GRAVITY_EARTH;
                shake=0.00f;

                gyroscope=sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
                if(gyroscope!=null)
                    sensorManager.registerListener(MainActivity.this,gyroscope,SensorManager.SENSOR_DELAY_NORMAL);
                else
                {
                    Toast.makeText(MainActivity.this,"Gyroscope not suported",Toast.LENGTH_SHORT).show();
                    gxvalue.setText("not supported");
                    gyvalue.setText("not supported");
                    gzvalue.setText("not supported");
                }

                locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                boolean isGPS=locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
                if (isGPS)
                   locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,20,10,MainActivity.this);
                else
                    Toast.makeText(MainActivity.this,"Please allow permission",Toast.LENGTH_SHORT).show();

                or=sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION);
                if(or!=null)
                    sensorManager.registerListener(MainActivity.this,or,SensorManager.SENSOR_DELAY_NORMAL);
                else
                    Toast.makeText(MainActivity.this,"Orientation not suported",Toast.LENGTH_SHORT).show();

                prox=sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
                if(prox!=null)
                    sensorManager.registerListener(MainActivity.this,prox,SensorManager.SENSOR_DELAY_NORMAL);
                else
                    Toast.makeText(MainActivity.this,"Proximity not suported",Toast.LENGTH_SHORT).show();
            }
        });
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start.setEnabled(true);
                stop.setEnabled(false);
                sensorManager.unregisterListener(MainActivity.this);
                xvalue.setText(" "); gxvalue.setText(" ");
                yvalue.setText(" "); gyvalue.setText(" ");
                zvalue.setText(" "); gzvalue.setText(" ");
                lat.setText(" "); lon.setText(" ");
                ox.setText(" "); oy.setText(" "); oz.setText(" ");
                proximity.setText(" ");
            }
        });
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(prox!=null && or!=null)
                {
                    int rotation=getWindowManager().getDefaultDisplay().getRotation();
                    switch (rotation)
                    {
                        case Surface.ROTATION_0:
                        {
                            Toast.makeText(MainActivity.this,"Screen Orientation Portrait",Toast.LENGTH_SHORT).show();
                            break;
                        }
                        case Surface.ROTATION_90:
                        {
                            Toast.makeText(MainActivity.this,"Screen Orientation Landscape",Toast.LENGTH_SHORT).show();
                            break;
                        }
                        case Surface.ROTATION_180:
                        {
                            Toast.makeText(MainActivity.this,"Screen Orientation Reverse Portrait",Toast.LENGTH_SHORT).show();
                            break;
                        }
                        case Surface.ROTATION_270:
                        {
                            Toast.makeText(MainActivity.this,"Screen Orientation Reverse Landscape",Toast.LENGTH_SHORT).show();
                            break;
                        }
                        default:
                        {
                            Toast.makeText(MainActivity.this,"Screen Orientation Portrait",Toast.LENGTH_SHORT).show();
                            break;
                        }
                    }
                }
                else
                    Toast.makeText(MainActivity.this,"Please Start Sensors",Toast.LENGTH_SHORT).show();

            }
        });
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        Sensor sensor=event.sensor;
        if(sensor.getType()==Sensor.TYPE_ACCELEROMETER)
        {
            xvalue.setText(String.valueOf(event.values[0]));
            yvalue.setText(String.valueOf(event.values[1]));
            zvalue.setText(String.valueOf(event.values[2]));
            insert_acc(event.values[0],event.values[1],event.values[2]);
            al=aval;
            aval=(float) Math.sqrt((double) (event.values[0]*event.values[0]+(event.values[1]*event.values[1])+(event.values[2]*event.values[2])));
            float ans=aval-al;
            shake=shake * 0.9f + ans;
            Log.d(TAG,"shake------   "+shake);
            if(shake>12)
                Toast.makeText(MainActivity.this,"Shake detected",Toast.LENGTH_SHORT).show();

        }
        if(sensor.getType()==Sensor.TYPE_GYROSCOPE)
        {
            gxvalue.setText(String.valueOf(event.values[0]));
            gyvalue.setText(String.valueOf(event.values[1]));
            gzvalue.setText(String.valueOf(event.values[2]));
            insert_gyr(event.values[0],event.values[1],event.values[2]);
        }
        if (sensor.getType()==Sensor.TYPE_ORIENTATION)
        {
            ox.setText(String.valueOf(event.values[1]));
            oy.setText(String.valueOf(event.values[2]));
            oz.setText(String.valueOf(event.values[0]));
            inset_orien(event.values[1],event.values[2],event.values[0]);
        }
        if(sensor.getType()==Sensor.TYPE_PROXIMITY)
        {
            proximity.setText(String.valueOf(event.values[0]));
            insert_prox(event.values[0]);
        }
    }

    private void insert_prox(float value)
    {
        SQLiteDatabase sqLiteDatabase=myDatabase.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(col_p,value);
        contentValues.put(col_ptimestamp, new SimpleDateFormat("HH:mm:ss dd-MM-yyyy", Locale.getDefault()).format(new Date()));
        sqLiteDatabase.insert(Table_proximity,null,contentValues);
    }

    private void inset_orien(float x, float y, float z)
    {
        SQLiteDatabase sqLiteDatabase=myDatabase.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(col_ox,x);
        contentValues.put(col_oy,y);
        contentValues.put(col_oz,z);
        contentValues.put(col_otimestamp, new SimpleDateFormat("HH:mm:ss dd-MM-yyyy", Locale.getDefault()).format(new Date()));
        sqLiteDatabase.insert(Table_orinetation,null,contentValues);
    }

    private void insert_gyr(float x, float y, float z)
    {
        SQLiteDatabase sqLiteDatabase=myDatabase.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(col_gx,x);
        contentValues.put(col_gy,y);
        contentValues.put(col_gz,z);
        contentValues.put(col_gtimestamp, new SimpleDateFormat("HH:mm:ss dd-MM-yyyy", Locale.getDefault()).format(new Date()));
        sqLiteDatabase.insert(Table_gyroscope,null,contentValues);
    }

    private void insert_acc(float x, float y, float z)
    {
        SQLiteDatabase sqLiteDatabase=myDatabase.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(col_ax,x);
        contentValues.put(col_ay,y);
        contentValues.put(col_az,z);
        contentValues.put(col_atimestamp, new SimpleDateFormat("HH:mm:ss dd-MM-yyyy", Locale.getDefault()).format(new Date()));
        sqLiteDatabase.insert(Table_accelerometer,null,contentValues);
    }
    

    @Override
    public void onLocationChanged(Location location)
    {
        lat.setText(String.valueOf(location.getLatitude()));
        lon.setText(String .valueOf(location.getLongitude()));
        inset_gps(location.getLatitude(),location.getLongitude());
    }

    private void inset_gps(double latitude, double longitude)
    {
        SQLiteDatabase sqLiteDatabase=myDatabase.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(col_lat,latitude);
        contentValues.put(col_lon,longitude);
        contentValues.put(col_timestamp, new SimpleDateFormat("HH:mm:ss dd-MM-yyyy", Locale.getDefault()).format(new Date()));
        sqLiteDatabase.insert(Table_gps,null,contentValues);
    }

    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
