package com.example.hp.quiz;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.ArrayList;

import com.example.hp.quiz.DatabaseHelper;
import com.nbsp.materialfilepicker.MaterialFilePicker;
import com.example.hp.quiz.MainActivity.*;
import com.nbsp.materialfilepicker.filter.CompositeFilter;
import com.nbsp.materialfilepicker.ui.FilePickerActivity;

public class SubmitFragment extends Fragment
{
    Context context;
    @Nullable
    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //progressDialog=new ProgressDialog(context);
        View view;
        view=inflater.inflate(R.layout.fragment_submit,container,false);
        Button button = (Button) view.findViewById(R.id.button2);
        Button button1=(Button) view.findViewById(R.id.button3);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                
                //Toast.makeText(inflater.getContext(), "yooo" ,Toast.LENGTH_SHORT).show();
//                File sd = Environment.getExternalStorageDirectory();
//                File data = Environment.getDataDirectory();
//                FileChannel source=null;
//                FileChannel destination=null;
//                String currentDBPath = "/data/data/com.example.hp.quiz/databases/quiz_app.db";
//                String backupDBPath = "/data/data/com.example.hp.quiz/databases/quiz_app.db";
//                File currentDB = new File(data, currentDBPath);
//                File backupDB = new File(sd, backupDBPath);
//                try {
//                    source = new FileInputStream(currentDB).getChannel();
//                    destination = new FileOutputStream(backupDB).getChannel();
//                    destination.transferFrom(source, 0, source.size());
//                    source.close();
//                    destination.close();
//                    Toast.makeText(inflater.getContext(), "DB Exported!", Toast.LENGTH_LONG).show();
//                } catch(IOException e) {
//                    e.printStackTrace();
//                }


//                DatabaseHelper dbhelper = new DatabaseHelper(inflater.getContext());
//                File exportDir = new File(Environment.getExternalStorageDirectory(), "");
//                if (!exportDir.exists())
//                {
//                    exportDir.mkdirs();
//                }
                DatabaseHelper dbhelper = new DatabaseHelper(inflater.getContext());
                FileWriter file = null;
                try {
                    Toast.makeText(inflater.getContext(), "Exported Successfully" ,Toast.LENGTH_SHORT).show();
                    file = new FileWriter(Environment.getExternalStorageDirectory());
                    SQLiteDatabase db = dbhelper.getReadableDatabase();
                    Cursor curCSV = db.rawQuery("SELECT * FROM " + " Table_save_ans ",null);
                    while(curCSV.moveToNext())
                    {
                        String arrStr[] ={curCSV.getString(0),curCSV.getString(1), curCSV.getString(2)};
                        //Toast.makeText(inflater.getContext(), arrStr[0] ,Toast.LENGTH_SHORT).show();
                        file.append(String.valueOf(arrStr[0]));
                        file.append(String.valueOf(arrStr[1]));
                        file.append(String.valueOf(arrStr[2]));
                        file.append("\n");
                    }
                    file.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
//                try
//                {
//                    Toast.makeText(inflater.getContext(), "Exported Successfully" ,Toast.LENGTH_SHORT).show();
//                    file.createNewFile();
//                    SQLiteDatabase db = dbhelper.getReadableDatabase();
//                    Cursor curCSV = db.rawQuery("SELECT * FROM " + " Table_questions ",null);
//
//                    while(curCSV.moveToNext())
//                    {
//                        String arrStr[] ={curCSV.getString(0),curCSV.getString(1), curCSV.getString(2)};
//                        file.
//                    }
//                    for (int j = 0; j < arrStr.length; j++) {
//                        writer.append(String.valueOf(wasp[j]));
//                        writer.append("\n");
//                    }
//                    writer.close();
//                    curCSV.close();
//                }
//                catch(Exception sqlEx)
//                {
//
//                }
            }
        });

        button1.setOnClickListener(new View.OnClickListener()
        {

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onClick(View v) {
//                ProgressDialog progressDialog=new ProgressDialog(context);
//                    progressDialog.setTitle("Uploading");
//                    progressDialog.setMessage("Please wait........");
//                    progressDialog.show();
//                Thread thread=new Thread(new Runnable() {
//                    @Override
//                    public void run() {
//
//                    }
//                });
//                thread.start();
            //new MaterialFilePicker().withActivity(mActivity).start();
                Toast.makeText(inflater.getContext(), "Uploaded" ,Toast.LENGTH_SHORT).show();
            }
        });
        return view;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

}
