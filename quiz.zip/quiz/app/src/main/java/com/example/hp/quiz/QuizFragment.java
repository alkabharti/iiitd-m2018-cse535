package com.example.hp.quiz;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class QuizFragment extends Fragment
{
    View v;
    private RecyclerView recyclerView;
    private List<View_questions> view_questions;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        v=inflater.inflate(R.layout.quiz_fragment,container,false);
        recyclerView=(RecyclerView) v.findViewById(R.id.recycler_questions);
        RecyclerViewAdapter recyclerViewAdapter=new RecyclerViewAdapter(getContext(),view_questions);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(recyclerViewAdapter);
        return v;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        view_questions=new ArrayList<>();
        view_questions.add(new View_questions("1.","The ++ operator increments the operand by 1, whereas, the -- operator decrements it by 1."));
        view_questions.add(new View_questions("2.","It is necessary that a loop counter must only be an int. It cannot be a float."));
        view_questions.add(new View_questions("3.","A zero value is considered to be false and a non-zero value is considered to be true."));
        view_questions.add(new View_questions("4.","= is used for comparison, whereas, == is used for assignment of two quantities."));
        view_questions.add(new View_questions("5.","Blank spaces may be inserted between two words to improve the readability of the statement. "));
        view_questions.add(new View_questions("6.","The keywords cannot be used as variable names."));
        view_questions.add(new View_questions("7.","continue keyword skip one iteration of loop? "));
        view_questions.add(new View_questions("8.","Switch statement can have any number of case instances "));
        view_questions.add(new View_questions("9.","Two case constants within the same switch statement can have the same value."));
        view_questions.add(new View_questions("10.","ferror( ) reports any error that might have occurred during a read/write operation on a file. "));
        view_questions.add(new View_questions("11.","A file opened for writing already exists its contents would be overwritten. "));
        view_questions.add(new View_questions("12.","Structure is collection of dissimilar data types. "));
        view_questions.add(new View_questions("13.","A do-while loop is used to ensure that the statements within the loop are executed at least twice. "));
        view_questions.add(new View_questions("14.","Whaling / Whaling attack is a kind of phishing attacks that target senior executives and other high profile to access valuable information. "));
        view_questions.add(new View_questions("15.","Freeware is software that is available for use at no monetary cost. "));
        view_questions.add(new View_questions("16.","IPv6 Internet Protocol address is represented as eight groups of four Octal digits."));
        view_questions.add(new View_questions("17.","The hexadecimal number system contains digits from 1 - 15."));
        view_questions.add(new View_questions("18.","Octal number system contains digits from 0 - 7. "));
        view_questions.add(new View_questions("19.","MS Word is a hardware. "));
        view_questions.add(new View_questions("20.","CPU controls only input data of computer. "));
        view_questions.add(new View_questions("21.","CPU stands for Central Performance Unit. "));
        view_questions.add(new View_questions("22.","The Language that the computer can understand is called Machine Language."));
        view_questions.add(new View_questions("23.","Magnetic Tape used random access method."));
        view_questions.add(new View_questions("24.","Twitter is an online social networking and blogging service. "));
        view_questions.add(new View_questions("25.","Worms and trojan horses are easily detected and eliminated by antivirus software. "));
        view_questions.add(new View_questions("26.","Dot-matrix, Deskjet, Inkjet and Laser are all types of Printers. "));
        view_questions.add(new View_questions("27.","GNU / Linux is a open source operating system. "));
        view_questions.add(new View_questions("28.","switch is not an iterative statement? "));
        view_questions.add(new View_questions("29.","BST data structure is not linear"));
        view_questions.add(new View_questions("30.","A full binary tree with n leaves contains n nodes "));


    }
}
