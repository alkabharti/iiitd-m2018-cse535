package com.example.hp.quiz;

public class View_questions
{
    private String qnumber;
    private String question;

    public View_questions() {

    }
    public View_questions(String qnumber, String question) {
        this.qnumber = qnumber;
        this.question = question;
    }

    public String getQnumber() {
        return qnumber;
    }

    public void setQnumber(String qnumber) {
        this.qnumber = qnumber;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }
}
