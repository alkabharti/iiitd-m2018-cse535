package com.example.hp.quiz;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder>
{

    Context mcontext;
    List<View_questions> questions;
    Fragment fragment1;
    Dialog fragment;
    RadioGroup radioGroup;
    RadioButton radioButton;
    Button save;
    TextView question;
    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;
    Cursor cursor1;
    Cursor cursor2;
    public List<View_questions> questionsList;
    public RecyclerViewAdapter(Context mcontext, List<View_questions> questions) {
        this.mcontext = mcontext;
        this.questions = questions;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, final int i) {
        View view=LayoutInflater.from(mcontext).inflate(R.layout.questions,viewGroup,false);
        final MyViewHolder myViewHolder=new MyViewHolder(view);
        fragment1=new Fragment();
        fragment1.getView();
        openHelper=new DatabaseHelper(mcontext);
        DatabaseHelper databaseHelper=new DatabaseHelper(mcontext);
        questionsList=databaseHelper.AllQuestions();
        myViewHolder.question_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OptionsFragment optionsFragment=new OptionsFragment();
                optionsFragment.view();
                fragment=new Dialog(mcontext,android.R.style.Theme_Black_NoTitleBar_Fullscreen);
                fragment.setContentView(R.layout.fragment_options);
                TextView qno=(TextView) fragment.findViewById(R.id.textView8);
                TextView question=(TextView) fragment.findViewById(R.id.textView9);
                qno.setText(questions.get(myViewHolder.getAdapterPosition()).getQnumber());
                question.setText(questions.get(myViewHolder.getAdapterPosition()).getQuestion());
                //Toast.makeText(mcontext, "Clicked", Toast.LENGTH_SHORT).show();
                fragment.show();
                radioGroup=(RadioGroup) fragment.findViewById(R.id.radioGroup);
                save=(Button) fragment.findViewById(R.id.button);
                question=(TextView) fragment.findViewById(R.id.textView9);
                final TextView finalQuestion = question;
                save.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int selectedid=radioGroup.getCheckedRadioButtonId();
                        radioButton=(RadioButton) fragment.findViewById(selectedid);
                        String text = radioButton.getText().toString();
                        String ques= finalQuestion.getText().toString();
                        db=openHelper.getWritableDatabase();
                        db=openHelper.getReadableDatabase();
                        String query=" SELECT " + DatabaseHelper.col_save_3+" FROM "+ DatabaseHelper.Table_save_ans+"";
                        cursor2=db.rawQuery(query,null);
                        if (cursor2!=null)
                        {
                            if (cursor2.getCount()>0)
                                cursor2.moveToNext();
                        }
                        insertdata(text,ques);

                        Toast.makeText(mcontext,"Submitted answer is"+text,Toast.LENGTH_LONG).show();
                    }
                });

            }
        });
        return myViewHolder;
    }

    public void insertques(String ques)
    {
        ContentValues contentValues=new ContentValues();
        contentValues.put(DatabaseHelper.col_question_2,ques);
        long id1=db.insert(DatabaseHelper.Table_questions,null,contentValues);
    }
    public void insertdata(String value,String ques)
    {
        ContentValues contentValues=new ContentValues();
        contentValues.put(DatabaseHelper.col_save_2,ques);
        contentValues.put(DatabaseHelper.col_save_3,value);
        long id=db.insert(DatabaseHelper.Table_save_ans,null,contentValues);
    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter.MyViewHolder myViewHolder, int i) {
        myViewHolder.qno.setText(questions.get(i).getQnumber());
        myViewHolder.ques.setText(questions.get(i).getQuestion());
    }

    @Override
    public int getItemCount() {
        return questions.size();
    }
//    public void getans(String text,String ques) throws IOException {
//        FileWriter writer;
//        String path="C:\\Users\\hp\\Desktop\\ans.csv";
//        ArrayList<HashMap<String,String>> questions=new ArrayList<HashMap<String, String>>();
//        HashMap<String,String> hashMap=new HashMap<String, String>();
//        hashMap.put(ques,text);
//        writer=new FileWriter(path,true);
//        for (int i=0;i<questions.size();i++)
//        {
//            writer.write(questions.indexOf(i));
//            writer.write(",");
//        }
//        writer.close();
//
//
//    }
    public static class MyViewHolder extends RecyclerView.ViewHolder
    {
        Context context;
        public List<View_questions> questionsList;
        public RelativeLayout question_details;
        public TextView qno;
        public TextView ques;
        String q;
        public MyViewHolder(View itemView)
        {
            super(itemView);
            question_details=(RelativeLayout) itemView.findViewById(R.id.questions_option);
            qno=(TextView) itemView.findViewById(R.id.textView5);
            ques=(TextView) itemView.findViewById(R.id.textView6);
//            DatabaseHelper databaseHelper=new DatabaseHelper(context);
//            questionsList=databaseHelper.AllQuestions();

        }
    }
}
