package com.example.hp.quiz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper
{
    public SQLiteDatabase db;
    public static final String Database_name="quiz_app.db";
    public static final String Table_questions="questions";
    public static final String Table_save_ans="save_answers";

    public static final String col_question_1="ID";
    public static final String col_question_2="qnum";
    public static final String col_question_3="questions";

    public static final String col_save_1="ID";
    public static final String col_save_2="question";
    public static final String col_save_3="option";


    public DatabaseHelper( Context context)
    {
        super(context,Database_name,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        this.db=db;
        db.execSQL(" CREATE TABLE "+Table_questions+ " (ID INTEGER PRIMARY KEY AUTOINCREMENT, qnum TEXT, questions TEXT) ");
        db.execSQL(" CREATE TABLE "+Table_save_ans+ " (ID INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT, option TEXT) ");
        fillQuestionTable();
    }

    public void fillQuestionTable()
    {
        View_questions q1=new View_questions("1.","The ++ operator increments the operand by 1, whereas, the -- operator decrements it by 1.");
        View_questions q2=new View_questions("2.","It is necessary that a loop counter must only be an int. It cannot be a float.");
        View_questions q3=new View_questions("3.","A zero value is considered to be false and a non-zero value is considered to be true.");
        View_questions q4=new View_questions("4.","= is used for comparison, whereas, == is used for assignment of two quantities.");
        View_questions q5=new View_questions("5.","Blank spaces may be inserted between two words to improve the readability of the statement. ");
        View_questions q6=new View_questions("6.","The keywords cannot be used as variable names.");
        View_questions q7=new View_questions("7.","continue keyword skip one iteration of loop? ");
        View_questions q8=new View_questions("8.","Switch statement can have any number of case instances ");
        View_questions q9=new View_questions("9.","Two case constants within the same switch statement can have the same value.");
        View_questions q10=new View_questions("10.","ferror( ) reports any error that might have occurred during a read/write operation on a file. ");
        View_questions q11=new View_questions("11.","A file opened for writing already exists its contents would be overwritten. ");
        View_questions q12=new View_questions("12.","Structure is collection of dissimilar data types. ");
        View_questions q13=new View_questions("13.","A do-while loop is used to ensure that the statements within the loop are executed at least twice. ");
        View_questions q14=new View_questions("14.","Whaling / Whaling attack is a kind of phishing attacks that target senior executives and other high profile to access valuable information. ");
        View_questions q15=new View_questions("15.","Freeware is software that is available for use at no monetary cost. ");
        View_questions q16=new View_questions("16.","IPv6 Internet Protocol address is represented as eight groups of four Octal digits.");
        View_questions q17=new View_questions("17.","The hexadecimal number system contains digits from 1 - 15.");
        View_questions q18=new View_questions("18.","Octal number system contains digits from 0 - 7. ");
        View_questions q19=new View_questions("19.","MS Word is a hardware. ");
        View_questions q20=new View_questions("20.","CPU controls only input data of computer. ");
        View_questions q21=new View_questions("21.","CPU stands for Central Performance Unit. ");
        View_questions q22=new View_questions("22.","The Language that the computer can understand is called Machine Language.");
        View_questions q23=new View_questions("23.","Magnetic Tape used random access method.");
        View_questions q24=new View_questions("24.","Twitter is an online social networking and blogging service. ");
        View_questions q25=new View_questions("25.","Worms and trojan horses are easily detected and eliminated by antivirus software. ");
        View_questions q26=new View_questions("26.","Dot-matrix, Deskjet, Inkjet and Laser are all types of Printers. ");
        View_questions q27=new View_questions("27.","GNU / Linux is a open source operating system. ");
        View_questions q28=new View_questions("28.","switch is not an iterative statement? ");
        View_questions q29=new View_questions("29.","BST data structure is not linear");
        View_questions q30=new View_questions("30.","A full binary tree with n leaves contains n nodes ");

        addQ(q1);addQ(q2);addQ(q3);addQ(q4);addQ(q5);addQ(q6);addQ(q7);addQ(q8);addQ(q9);addQ(q10);
        addQ(q11);addQ(q12);addQ(q13);addQ(q14);addQ(q15);addQ(q16);addQ(q17);addQ(q18);addQ(q19);addQ(q20);
        addQ(q21);addQ(q22);addQ(q23);addQ(q24);addQ(q25);addQ(q26);addQ(q27);addQ(q28);addQ(q29);addQ(q30);

    }
    public void addQ(View_questions q1)
    {
        ContentValues contentValues=new ContentValues();
        contentValues.put(col_question_2,q1.getQnumber());
        contentValues.put(col_question_3,q1.getQuestion());
        db.insert(Table_questions,null,contentValues);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL(String.format("DROP TABLE IF EXISTS", Table_questions));
        db.execSQL(String.format("DROP TABLE IF EXISTS", Table_save_ans));
        onCreate(db);

    }
    public List<View_questions> AllQuestions()
    {
        List<View_questions> question_list=new ArrayList<>();
        db=getReadableDatabase();
        Cursor c=db.rawQuery("SELECT * FROM "+ Table_questions,null);
        if((c.moveToFirst()))
        {
            do {
                View_questions view_question=new View_questions();
                view_question.setQnumber(c.getString(c.getColumnIndex(col_question_2)));
                view_question.setQuestion(c.getString(c.getColumnIndex(col_question_3)));
                question_list.add(view_question);
            }
            while (c.moveToNext());
        }
        c.close();
        return question_list;
    }
    public Cursor raw() {

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM " + Table_save_ans , new String[]{});

        return res;
    }
}
