package com.alka.music_player.Util.widget.PlayerPanel;

public interface OnPlayPauseToggleListener {
    void onToggled();
}
