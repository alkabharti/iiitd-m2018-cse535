package com.alka.music_player;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alka.music_player.Service.MusicService;
import com.alka.music_player.Service.PC;
import com.alka.music_player.Service.PlayerFunctions;
import java.util.ArrayList;

public class SongListAdapter extends BaseAdapter  {
    ArrayList<Song> data;
    Activity activity;

    public SongListAdapter(ArrayList<Song> data, Activity activity) {
        this.data = data;
        this.activity = activity;
    }
    @Override
    public int getCount() {
        return data.size();
    }
    @Override
    public Object getItem(int position) {
        return data.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(final int position, View cv, ViewGroup parent) {
           cv = activity.getLayoutInflater().inflate(R.layout.list_item_songs, parent, false);
            TextView songName = (TextView) cv.findViewById(R.id.songName);
            TextView artalbname = (TextView) cv.findViewById(R.id.artalbname);
            View divider = cv.findViewById(R.id.dividerView);
            if (position == data.size() - 1) {
                divider.setVisibility(View.GONE);
            }
            final Song item = data.get(position);
            songName.setText(item.getName());
            artalbname.setText(item.getAlbumName() + " - " + item.getArtistName());
            cv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SongListActivity.mpv.start();
                    PC.SONG_PAUSED = false;
                    PC.SONG_NUMBER = position;
                    boolean isServiceRunning = PlayerFunctions.isServiceRunning(MusicService.class.getName(), activity.getApplicationContext());
                    if (!isServiceRunning) {
                        Intent i = new Intent(activity.getApplicationContext(), MusicService.class);
                        activity.startService(i);
                    } else {
                        PC.SONG_CHANGE_HANDLER.sendMessage(PC.SONG_CHANGE_HANDLER.obtainMessage());
                    }

                }
            });

        return cv;
    }

}
