package com.alka.music_player.Service;

import java.util.ArrayList;
import android.os.Handler;

import com.alka.music_player.Song;

public class PC {
	public static ArrayList<Song> SONGS_LIST = new ArrayList<Song>();
	public static int SONG_NUMBER = 0;
	public static boolean SONG_PAUSED = true;
	public static Handler SONG_CHANGE_HANDLER;
	public static Handler PLAY_PAUSE_HANDLER;
	public static Handler PROGRESSBAR_HANDLER;
}
