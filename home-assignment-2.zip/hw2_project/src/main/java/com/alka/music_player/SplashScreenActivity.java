package com.alka.music_player;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class SplashScreenActivity extends AppCompatActivity {
    long queueid;
    DownloadManager dm;
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        final Button playlist = (Button) findViewById(R.id.button);
        Button download = (Button) findViewById(R.id.button3);
        Button airplane = (Button) findViewById(R.id.button2);
        Button charge = (Button) findViewById(R.id.button4);
        BroadcastReceiver br = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)) {
                    DownloadManager.Query query = new DownloadManager.Query();
                    query.setFilterById(queueid);
                    Cursor c = dm.query(query);
                    if (c.moveToFirst()) {
                        int cindex = c.getColumnIndex(DownloadManager.COLUMN_STATUS);
                        if (DownloadManager.STATUS_SUCCESSFUL == c.getInt(cindex)) {
                            Toast.makeText(SplashScreenActivity.this, "Downloaded successfully", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        };
        registerReceiver(br,new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
        playlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SplashScreenActivity.this, SongListActivity.class);
                startActivity(intent);

            }
        });

        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = cm.getActiveNetworkInfo();
                if (netInfo != null && netInfo.isConnectedOrConnecting()) {
                    Toast.makeText(SplashScreenActivity.this, "You are connected to Internet", Toast.LENGTH_SHORT).show();
                    dm=(DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    DownloadManager.Request request=new DownloadManager.Request(Uri.parse("http://faculty.iiitd.ac.in/~mukulika/s1.mp3"));
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir("G:\\Music_app\\app\\src\\main\\res\\raw","http://faculty.iiitd.ac.in/~mukulika/s1.mp3");
                    queueid=dm.enqueue(request);
                } else
                    Toast.makeText(SplashScreenActivity.this, "You are not connected to Internet", Toast.LENGTH_SHORT).show();


            }
        });
        final MediaPlayer mpButtonClick1;
        mpButtonClick1 = MediaPlayer.create(this, R.raw.s1);
        ImageButton play = (ImageButton) findViewById(R.id.imageButton);
        play.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mpButtonClick1.isPlaying()) {
                    mpButtonClick1.stop();
                }
                else {
                    mpButtonClick1.start();
                }
            }

        });

   airplane.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Check_airplane_mode();
            }
        });
        charge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                check_charging();
            }
        });

    }

    public static boolean isConnected(Context context) {
        Intent intent = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
        return plugged == BatteryManager.BATTERY_PLUGGED_AC || plugged == BatteryManager.BATTERY_PLUGGED_USB;
    }
    public void check_charging()
    {
        if(isConnected(this))
            Toast.makeText(this, "Phone is charging", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(this, "not charging", Toast.LENGTH_SHORT).show();
    }
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    private static boolean isAirplaneModeOn(Context context) {

        return Settings.Global.getInt(context.getContentResolver(),
                Settings.Global.AIRPLANE_MODE_ON, 0) != 0;

    }
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    private void Check_airplane_mode()
    {
        if(isAirplaneModeOn(this)==true)
            Toast.makeText(this, "Airplane mode on", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(this, "Airplane mode off", Toast.LENGTH_SHORT).show();
    }

}