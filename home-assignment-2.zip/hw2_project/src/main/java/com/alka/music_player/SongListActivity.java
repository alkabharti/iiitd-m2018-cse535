package com.alka.music_player;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.alka.music_player.Service.MusicControls;
import com.alka.music_player.Util.widget.IndexableListView;
import com.alka.music_player.Service.MusicService;
import com.alka.music_player.Service.PlayerFunctions;
import com.alka.music_player.Util.widget.PlayerPanel.PlayerPanelView;
import com.alka.music_player.Util.widget.PlayerPanel.MusicPlayerView;

public class SongListActivity extends Activity {
    static int pausedProgress = 0;
    RelativeLayout playerPanel;
    public static SeekBar trackseekbar;
    public static SeekBar volumeseekbar;
    public static TextView panelMusicTitle, insideMusicTitle, insideMusicArtist;
    public static ImageView panelPlayPauseBtn;
    public static PlayerPanelView playerPanelView;
    public static RelativeLayout playPauseLayout;
    public static MusicPlayerView mpv;
    IndexableListView listView;
    SongListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_list);
        trackseekbar = (SeekBar) findViewById(R.id.seekBar);
        volumeseekbar = (SeekBar) findViewById(R.id.seekBar2);
        playerPanel = (RelativeLayout) findViewById(R.id.playerPanel);
        playerPanel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        listView = (IndexableListView) findViewById(R.id.list);
        listView.setFastScrollEnabled(true);
        adapter = new SongListAdapter( PlayerFunctions.listOfSongs(getApplicationContext()), SongListActivity.this);
        listView.setAdapter(adapter);
        panelMusicTitle = (TextView) findViewById(R.id.textView);
        insideMusicTitle = (TextView) findViewById(R.id.textViewSong);
        insideMusicArtist = (TextView) findViewById(R.id.textViewSinger);
        panelPlayPauseBtn = (ImageView) findViewById(R.id.imageView3);
        mpv = (MusicPlayerView) findViewById(R.id.mpv);

        panelPlayPauseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MusicService.mp.isPlaying()) {
                    panelPlayPauseBtn.setImageResource(R.drawable.ic_play);
                    MusicControls.pauseControl(getApplicationContext());
                } else {
                    panelPlayPauseBtn.setImageResource(R.drawable.ic_pause);
                    MusicControls.playControl(getApplicationContext());
                }
            }
        });

        playerPanelView = (PlayerPanelView) findViewById(R.id.sliding_layout);
        playPauseLayout = (RelativeLayout) findViewById(R.id.playPauseLayout);
        if (MusicService.mp != null) {
            if (!MusicService.mp.isPlaying()) {
                playerPanelView.setPanelHeight(0);
            } else {
                playerPanelView.setPanelHeight(playPauseLayout.getHeight());
            }
        } else {
            playerPanelView.setPanelHeight(0);
        }
        playerPanelView.addPanelSlideListener(new PlayerPanelView.PanelSlideListener() {
            @Override
            public void onPanelSlide(View panel, float slideOffset) {
            }
            @Override
            public void onPanelStateChanged(View panel, PlayerPanelView.PanelState previousState, PlayerPanelView.PanelState newState) {
                if (newState == PlayerPanelView.PanelState.EXPANDED) {
                    playPauseLayout.setVisibility(View.GONE);
                } else {
                    playPauseLayout.setVisibility(View.VISIBLE);
                }
            }
        });

    }
    public static void updateUI(Song song, final Context activity, boolean pause) {
        playerPanelView.setPanelHeight(playPauseLayout.getHeight());
        panelMusicTitle.setText(song.getName());
        mpv.setProgress(pausedProgress);
        mpv.setMax((int) (MusicService.mp.getDuration() / 1000));
        insideMusicTitle.setText(song.getName());
        insideMusicArtist.setText(song.getArtistName());
        trackseekbar.setMax(MusicService.mp.getDuration() / 1000);
        trackseekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                MusicService.mp.seekTo(progress * 1000);
                mpv.setProgress(progress);
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        mpv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MusicService.mp.isPlaying()) {
                    pausedProgress = MusicService.mp.getCurrentPosition();
                    MusicControls.pauseControl(activity);
                } else {
                    MusicControls.playControl(activity);

                }
            }
        });
        if (pause) {
            mpv.stop();
            panelPlayPauseBtn.setImageResource(R.drawable.ic_play);
        } else {
            mpv.start();
            mpv.setProgress(pausedProgress);
            panelPlayPauseBtn.setImageResource(R.drawable.ic_pause);
        }
    }
}
